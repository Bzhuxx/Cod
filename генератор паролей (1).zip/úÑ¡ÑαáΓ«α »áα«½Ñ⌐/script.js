function gen_password(len){
    if(len > 10) len = 10;
    len = len * (-1);
    return Math.random().toString(36).slice(len);
}
gen_password();
alert(len);